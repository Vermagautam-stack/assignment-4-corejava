import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

class Inventory {
    private HashMap<Integer, Integer> stock = new HashMap<>();

    void addProduct(int id, int qty) {
        stock.put(id, qty);
        System.out.println("Product " + id + " added with stock " + qty);
    }

    void updateStock(int id, int qty) {
        if (stock.containsKey(id)) {
            stock.put(id, qty);
            System.out.println("Product " + id + " stock updated to " + qty);
        } else {
            System.out.println("Product " + id + " not found.");
        }
    }

    void displayInventory() {
        if (stock.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }
        Iterator<Map.Entry<Integer, Integer>> it = stock.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> e = it.next();
            System.out.println("Product ID: " + e.getKey() + " | Stock: " + e.getValue());
        }
    }
}

public class Q4_Inventory {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Inventory inv = new Inventory();
        int choice;
        do {
            System.out.println("\n1. Add Product");
            System.out.println("2. Update Stock");
            System.out.println("3. Display Inventory");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            choice = Integer.parseInt(sc.nextLine().trim());
            switch (choice) {
                case 1:
                    System.out.print("Enter Product ID: ");
                    int id = Integer.parseInt(sc.nextLine().trim());
                    System.out.print("Enter Stock: ");
                    inv.addProduct(id, Integer.parseInt(sc.nextLine().trim()));
                    break;
                case 2:
                    System.out.print("Enter Product ID: ");
                    int pid = Integer.parseInt(sc.nextLine().trim());
                    System.out.print("Enter new Stock: ");
                    inv.updateStock(pid, Integer.parseInt(sc.nextLine().trim()));
                    break;
                case 3:
                    inv.displayInventory();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 4);
        sc.close();
    }
}
