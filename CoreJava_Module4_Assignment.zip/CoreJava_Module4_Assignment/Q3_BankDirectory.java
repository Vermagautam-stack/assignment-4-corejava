import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class BankDirectory {
    private HashMap<Integer, String> accounts = new HashMap<>();

    void addAccount(int accNo, String name) {
        accounts.put(accNo, name);
        System.out.println("Account added successfully.");
        System.out.println("Account No: " + accNo + " \u2192 " + name);
    }

    void getCustomer(int accNo) {
        String name = accounts.get(accNo);
        if (name != null) {
            System.out.println("Account No: " + accNo + " \u2192 " + name);
        } else {
            System.out.println("Account not found.");
        }
    }

    void displayAll() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts available.");
            return;
        }
        for (Map.Entry<Integer, String> e : accounts.entrySet()) {
            System.out.println("Account No: " + e.getKey() + " \u2192 " + e.getValue());
        }
    }
}

public class Q3_BankDirectory {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BankDirectory bank = new BankDirectory();
        int choice;
        do {
            System.out.println("\n1. Add Account");
            System.out.println("2. Get Customer Name");
            System.out.println("3. Display All Accounts");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            choice = Integer.parseInt(sc.nextLine().trim());
            switch (choice) {
                case 1:
                    System.out.print("Enter Account No: ");
                    int no = Integer.parseInt(sc.nextLine().trim());
                    System.out.print("Enter Customer Name: ");
                    bank.addAccount(no, sc.nextLine());
                    break;
                case 2:
                    System.out.print("Enter Account No: ");
                    bank.getCustomer(Integer.parseInt(sc.nextLine().trim()));
                    break;
                case 3:
                    bank.displayAll();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 4);
        sc.close();
    }
}
