import java.util.HashSet;
import java.util.Scanner;

class Attendance {
    private HashSet<String> present = new HashSet<>();

    void markAttendance(String name) {
        if (present.add(name)) {          // add() returns false for duplicates
            System.out.println("Attendance marked for " + name);
        } else {
            System.out.println(name + " is already marked present");
        }
    }

    void displayAttendance() {
        System.out.println("Students present: " + present);
    }
}

public class Q2_Attendance {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Attendance att = new Attendance();
        while (true) {
            System.out.print("Enter name to mark attendance (or 'done' to finish): ");
            String name = sc.nextLine().trim();
            if (name.equalsIgnoreCase("done")) {
                break;
            }
            att.markAttendance(name);
        }
        att.displayAttendance();
        sc.close();
    }
}
