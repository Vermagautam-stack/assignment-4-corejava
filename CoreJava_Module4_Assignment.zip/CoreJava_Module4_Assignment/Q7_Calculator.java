import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Q7_Calculator extends JFrame implements ActionListener {
    JTextField display;
    String first = "", second = "";
    char op = 0;
    boolean justCalculated = false;

    Q7_Calculator() {
        super("Calculator");
        getContentPane().setBackground(Color.BLUE);
        setLayout(new FlowLayout(FlowLayout.CENTER, 8, 8));

        display = new JTextField(14);
        display.setEditable(false);
        display.setHorizontalAlignment(JTextField.LEFT);
        add(display);

        JPanel grid = new JPanel(new GridLayout(4, 4, 6, 6));
        grid.setBackground(Color.BLUE);
        String[] keys = {
            "+", "1", "2", "3",
            "-", "4", "5", "6",
            "*", "7", "8", "9",
            "/", ".", "0", "C"
        };
        for (String k : keys) {
            JButton b = new JButton(k);
            b.addActionListener(this);
            grid.add(b);
        }
        add(grid);

        JButton equals = new JButton("=");
        equals.addActionListener(this);
        add(equals);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(260, 330);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        char c = cmd.charAt(0);

        if (cmd.equals("C")) {
            clearAll();
        } else if (Character.isDigit(c) || c == '.') {
            if (justCalculated) {      // start fresh after a result
                clearAll();
            }
            if (op == 0) {
                first += cmd;
            } else {
                second += cmd;
            }
            showExpression();
        } else if (cmd.equals("=")) {
            calculate();
        } else {                        // + - * /
            if (justCalculated) {
                // continue using the previous result as first operand
                justCalculated = false;
                second = "";
            }
            if (first.isEmpty()) {
                return;
            }
            if (!second.isEmpty()) {   // chained operation: 2+3+ ...
                calculate();
                justCalculated = false;
                second = "";
            }
            op = c;
            showExpression();
        }
    }

    void calculate() {
        if (first.isEmpty() || op == 0 || second.isEmpty()) {
            return;
        }
        try {
            double a = Double.parseDouble(first);
            double b = Double.parseDouble(second);
            double result;
            switch (op) {
                case '+': result = a + b; break;
                case '-': result = a - b; break;
                case '*': result = a * b; break;
                default:
                    if (b == 0) {
                        display.setText("Cannot divide by zero");
                        clearState();
                        return;
                    }
                    result = a / b;
            }
            display.setText(first + op + second + "=" + result);
            first = String.valueOf(result);
            second = "";
            justCalculated = true;
        } catch (NumberFormatException ex) {
            display.setText("Invalid input");
            clearState();
        }
    }

    void showExpression() {
        display.setText(first + (op == 0 ? "" : String.valueOf(op)) + second);
    }

    void clearState() {
        first = "";
        second = "";
        op = 0;
        justCalculated = false;
    }

    void clearAll() {
        clearState();
        display.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Q7_Calculator();
            }
        });
    }
}
