# CSIT751 (Core Java) – Module IV Practical Home Assignment

Collections and GUI Programming – solutions to Q1 to Q7.

| File | Topic |
|------|-------|
| Q1_Library.java | ArrayList (menu-driven) |
| Q2_Attendance.java | HashSet (no duplicates) |
| Q3_BankDirectory.java | HashMap<Integer, String> |
| Q4_Inventory.java | HashMap + Iterator |
| Q5_CourseEnrollment.java | LinkedHashSet (ordered + unique) |
| Q6_StudentRegistrationForm.java | AWT Frame, FlowLayout, pop-up Dialog |
| Q7_Calculator.java | Swing calculator with event handling |

## How to run
```
javac Q1_Library.java
java Q1_Library
```
(Replace Q1_Library with the file you want to run. Q6 and Q7 open a window.)

## Notes
- Q2 and Q5: type `done` to stop entering names and see the final list.
- Q6: shows the entered details in a pop-up dialog and on the console.
