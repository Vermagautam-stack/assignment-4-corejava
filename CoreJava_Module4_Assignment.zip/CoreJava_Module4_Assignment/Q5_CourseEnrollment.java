import java.util.LinkedHashSet;
import java.util.Scanner;

class CourseEnrollment {
    private LinkedHashSet<String> students = new LinkedHashSet<>();

    void enrollStudent(String name) {
        if (students.add(name)) {
            System.out.println("Enrolled: " + name);
        } else {
            System.out.println(name + " is already enrolled");
        }
    }

    void displayEnrolledStudents() {
        System.out.println("Enrolled Students: " + students);
    }
}

public class Q5_CourseEnrollment {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CourseEnrollment course = new CourseEnrollment();
        while (true) {
            System.out.print("Enroll (or 'done' to finish): ");
            String name = sc.nextLine().trim();
            if (name.equalsIgnoreCase("done")) {
                break;
            }
            course.enrollStudent(name);
        }
        course.displayEnrolledStudents();
        sc.close();
    }
}
