import java.awt.*;
import java.awt.event.*;

public class Q6_StudentRegistrationForm extends Frame implements ActionListener {
    TextField tfName, tfFather, tfRoll, tfAge;
    CheckboxGroup genderGroup;
    Checkbox male, female;
    Choice course;
    Checkbox drawing, singing, music, others;
    TextArea taAddress;
    Button submit, clear;

    Q6_StudentRegistrationForm() {
        super("Student Registration Form");
        setLayout(new FlowLayout(FlowLayout.LEFT, 15, 10));
        setBackground(new Color(55, 60, 75));
        setForeground(Color.WHITE);

        Label title = new Label("Registration Form");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(Color.YELLOW);
        add(title);

        add(new Label("Name:"));
        tfName = new TextField(30);
        add(tfName);

        add(new Label("Father Name:"));
        tfFather = new TextField(30);
        add(tfFather);

        add(new Label("Roll No:"));
        tfRoll = new TextField(30);
        add(tfRoll);

        add(new Label("Age:"));
        tfAge = new TextField(30);
        add(tfAge);

        add(new Label("Gender:"));
        genderGroup = new CheckboxGroup();
        male = new Checkbox("Male", genderGroup, true);
        female = new Checkbox("Female", genderGroup, false);
        add(male);
        add(female);

        add(new Label("Course:"));
        course = new Choice();
        course.add("Java");
        course.add("Python");
        course.add("C++");
        course.add("Web Development");
        add(course);

        add(new Label("Hobbies:"));
        drawing = new Checkbox("Drawing");
        singing = new Checkbox("Singing");
        music = new Checkbox("Music");
        others = new Checkbox("Others");
        add(drawing);
        add(singing);
        add(music);
        add(others);

        add(new Label("Address:"));
        taAddress = new TextArea(4, 30);
        taAddress.setForeground(Color.BLACK);
        add(taAddress);

        submit = new Button("Submit");
        submit.setBackground(Color.BLUE);
        submit.setForeground(Color.WHITE);
        clear = new Button("Clear All");
        clear.setBackground(Color.RED);
        clear.setForeground(Color.WHITE);
        add(submit);
        add(clear);

        submit.addActionListener(this);
        clear.addActionListener(this);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        setSize(460, 620);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == clear) {
            tfName.setText("");
            tfFather.setText("");
            tfRoll.setText("");
            tfAge.setText("");
            male.setState(true);
            course.select(0);
            drawing.setState(false);
            singing.setState(false);
            music.setState(false);
            others.setState(false);
            taAddress.setText("");
            return;
        }

        // Submit clicked: collect the data
        String hobbies = "";
        if (drawing.getState()) hobbies += "Drawing ";
        if (singing.getState()) hobbies += "Singing ";
        if (music.getState()) hobbies += "Music ";
        if (others.getState()) hobbies += "Others ";
        if (hobbies.isEmpty()) hobbies = "None";

        String details = "Name: " + tfName.getText()
                + "\nFather Name: " + tfFather.getText()
                + "\nRoll No: " + tfRoll.getText()
                + "\nAge: " + tfAge.getText()
                + "\nGender: " + genderGroup.getSelectedCheckbox().getLabel()
                + "\nCourse: " + course.getSelectedItem()
                + "\nHobbies: " + hobbies.trim()
                + "\nAddress: " + taAddress.getText();

        System.out.println("Registration Successful\n" + details);
        showPopup("Registration Successful!", details);
    }

    // AWT pop-up message box
    void showPopup(String title, String message) {
        final Dialog d = new Dialog(this, title, true);
        d.setLayout(new FlowLayout());
        d.setBackground(Color.WHITE);
        d.setForeground(Color.BLACK);
        TextArea ta = new TextArea("Student registered successfully!\n\n" + message, 10, 35,
                TextArea.SCROLLBARS_NONE);
        ta.setEditable(false);
        Button ok = new Button("OK");
        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                d.dispose();
            }
        });
        d.add(ta);
        d.add(ok);
        d.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent ev) {
                d.dispose();
            }
        });
        d.setSize(320, 280);
        d.setLocationRelativeTo(this);
        d.setVisible(true);
    }

    public static void main(String[] args) {
        new Q6_StudentRegistrationForm();
    }
}
